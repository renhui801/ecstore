<?php
/**
 * ShopEx licence
 *
 * @copyright  Copyright (c) 2005-2013 ShopEx Technologies Inc. (http://www.shopex.cn)
 * @license  http://ecos.shopex.cn/ ShopEx License
 */

/*基础配置项*/
$setting['author']='www.shopex.cn';
$setting['version']='v1.0';
$setting['name']='精品分类';
$setting['order']=0;
$setting['stime']='2014-06';
$setting['catalog']='商品相关';
$setting['description'] = '精品分类';
$setting['userinfo'] = '';
$setting['usual']    = '1';
$setting['tag']    = 'auto';
$setting['template'] = array(
                            'default.html'=>app::get('b2c')->_('默认')
                        );

?>
